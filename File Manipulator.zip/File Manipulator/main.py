import os
import shutil

# Task 1
with open("sample.txt", "w") as file:
    file.write("This is a sample text file for file operations.")

# Task 2
with open("sample.txt", "r") as file:
    content = file.read()
    print("Task 2 Output:")
    print(content)

# Task 3
with open("sample.txt", "a") as file:
    file.write("\nAdditional line added for file operations.")

#Task 4
os.makedirs("Files", exist_ok=True)

# Task5
shutil.move("sample.txt", os.path.join("Files", "sample.txt"))

# Task 6
with open("file1.txt", "w") as file:
    file.write("Content of file1.txt.")

with open("file2.txt", "w") as file:
    file.write("Content of file2.txt.")

# Task 7
os.rename("file1.txt", "renamed_file.txt")

# Task 8 SEARCH AND DESTROY
os.remove("file2.txt")

# Task 9
files_in_files_folder = os.listdir("Files")
print("\nTask 9 Output:")
print(files_in_files_folder)

#Task 10
shutil.make_archive("archive", "zip", ".", "Files")